package com.example.virtualcam.xposed;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ImageFormat;
import android.hardware.Camera;
import android.media.MediaMetadataRetriever;
import android.os.Environment;
import android.os.SystemClock;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class VirtualCamHook implements IXposedHookLoadPackage {
    private static final File ROOT =
            new File(Environment.getExternalStorageDirectory(), "VirtualCam");

    private static final Map<Camera, CamState> STATES = new ConcurrentHashMap<Camera, CamState>();

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        String pkg = lpparam.packageName;
        if ("com.example.virtualcam".equals(pkg)) return;
        if ("android".equals(pkg) || "system".equals(pkg)) return;

        try {
            hookCamera();
        } catch (Throwable t) {
            XposedBridge.log("VirtualCam hook failed: " + t);
        }
    }

    private static boolean hooked;

    private static synchronized void hookCamera() {
        if (hooked) return;
        hooked = true;

        // Track cameras opened with an explicit ID (front/back).
        XposedHelpers.findAndHookMethod(
                Camera.class, "open", int.class,
                new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam p) {
                        Camera c = (Camera) p.getResult();
                        if (c == null) return;
                        CamState s = new CamState();
                        s.cameraId = (Integer) p.args[0];
                        s.facing = facingForId(s.cameraId);
                        STATES.put(c, s);
                    }
                });

        XposedHelpers.findAndHookMethod(
                Camera.class, "open",
                new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam p) {
                        Camera c = (Camera) p.getResult();
                        if (c == null) return;
                        CamState s = new CamState();
                        s.cameraId = 0;
                        s.facing = facingForId(0);
                        STATES.put(c, s);
                    }
                });

        XposedHelpers.findAndHookMethod(Camera.class, "setPreviewCallback",
                Camera.PreviewCallback.class,
                new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam p) {
                        CamState s = state((Camera) p.thisObject);
                        s.previewCallback = (Camera.PreviewCallback) p.args[0];
                    }
                });

        XposedHelpers.findAndHookMethod(Camera.class, "setOneShotPreviewCallback",
                Camera.PreviewCallback.class,
                new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam p) {
                        CamState s = state((Camera) p.thisObject);
                        s.oneShotCallback = (Camera.PreviewCallback) p.args[0];
                    }
                });

        XposedHelpers.findAndHookMethod(Camera.class, "setPreviewCallbackWithBuffer",
                Camera.PreviewCallback.class,
                new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam p) {
                        CamState s = state((Camera) p.thisObject);
                        s.previewCallback = (Camera.PreviewCallback) p.args[0];
                    }
                });

        XposedHelpers.findAndHookMethod(Camera.class, "addCallbackBuffer",
                byte[].class,
                new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam p) {
                        CamState s = state((Camera) p.thisObject);
                        byte[] b = (byte[]) p.args[0];
                        if (b != null) s.buffer = b;
                    }
                });

        XposedHelpers.findAndHookMethod(Camera.class, "getParameters",
                new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam p) {
                        try {
                            Camera c = (Camera) p.thisObject;
                            CamState s = state(c);
                            Camera.Parameters params = (Camera.Parameters) p.getResult();
                            Camera.Size z = params.getPreviewSize();
                            if (z != null) {
                                s.width = z.width;
                                s.height = z.height;
                            }
                        } catch (Throwable ignored) {}
                    }
                });

        XposedHelpers.findAndHookMethod(Camera.class, "startPreview",
                new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam p) {
                        CamState s = state((Camera) p.thisObject);
                        ensureSize((Camera) p.thisObject, s);
                        startFeeder((Camera) p.thisObject, s);
                    }
                });

        XposedHelpers.findAndHookMethod(Camera.class, "stopPreview",
                new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam p) {
                        CamState s = state((Camera) p.thisObject);
                        s.stop();
                    }
                });

        XposedHelpers.findAndHookMethod(Camera.class, "setPreviewCallback",
                Camera.PreviewCallback.class,
                new XC_MethodHook() {
                    @Override protected void beforeHookedMethod(MethodHookParam p) {
                        CamState s = state((Camera) p.thisObject);
                        s.previewCallback = (Camera.PreviewCallback) p.args[0];
                    }
                });

        XposedHelpers.findAndHookMethod(Camera.class, "setOneShotPreviewCallback",
                Camera.PreviewCallback.class,
                new XC_MethodHook() {
                    @Override protected void beforeHookedMethod(MethodHookParam p) {
                        CamState s = state((Camera) p.thisObject);
                        s.oneShotCallback = (Camera.PreviewCallback) p.args[0];
                    }
                });

        XposedHelpers.findAndHookMethod(Camera.class, "takePicture",
                Camera.ShutterCallback.class,
                Camera.PictureCallback.class,
                Camera.PictureCallback.class,
                Camera.PictureCallback.class,
                new XC_MethodHook() {
                    @Override protected void beforeHookedMethod(MethodHookParam p) {
                        try {
                            Camera c = (Camera) p.thisObject;
                            CamState s = state(c);
                            if (!isEnabledForFacing(s)) return;

                            byte[] jpeg = MediaSource.loadJpeg(s.facing, s.width, s.height);
                            if (jpeg == null) return;

                            // Keep shutter/raw/postview untouched; replace JPEG callback.
                            Camera.PictureCallback jpegCb =
                                    (Camera.PictureCallback) p.args[3];
                            if (jpegCb != null) {
                                p.setResult(null);
                                final Camera.PictureCallback cb = jpegCb;
                                cb.onPictureTaken(jpeg, c);
                            }
                        } catch (Throwable t) {
                            XposedBridge.log("VirtualCam takePicture: " + t);
                        }
                    }
                });

        XposedBridge.log("VirtualCam Camera1 hooks installed");
    }

    private static CamState state(Camera c) {
        CamState s = STATES.get(c);
        if (s == null) {
            s = new CamState();
            s.facing = 0;
            STATES.put(c, s);
        }
        return s;
    }

    private static int facingForId(int id) {
        try {
            Camera.CameraInfo info = new Camera.CameraInfo();
            Camera.getCameraInfo(id, info);
            return info.facing;
        } catch (Throwable t) {
            return id == 1 ? Camera.CameraInfo.CAMERA_FACING_FRONT
                    : Camera.CameraInfo.CAMERA_FACING_BACK;
        }
    }

    private static boolean isEnabledForFacing(CamState s) {
        Config c = Config.read();
        if (!c.enabled) return false;
        return s.facing == Camera.CameraInfo.CAMERA_FACING_FRONT
                ? c.frontEnabled : c.backEnabled;
    }

    private static void ensureSize(Camera c, CamState s) {
        try {
            Camera.Parameters p = c.getParameters();
            Camera.Size z = p.getPreviewSize();
            if (z != null) {
                s.width = z.width;
                s.height = z.height;
            }
        } catch (Throwable ignored) {
            if (s.width <= 0) s.width = 640;
            if (s.height <= 0) s.height = 480;
        }
    }

    private static void startFeeder(final Camera c, final CamState s) {
        s.stop();
        Config cfg = Config.read();
        if (!cfg.enabled || !isEnabledForFacing(s)) return;

        final int fps = Math.max(1, Math.min(30, cfg.fps));
        s.running = true;
        s.executor = Executors.newSingleThreadScheduledExecutor();
        s.executor.scheduleAtFixedRate(new Runnable() {
            long frame = 0;
            @Override public void run() {
                if (!s.running) return;
                try {
                    byte[] data = MediaSource.frameNv21(
                            s.facing, s.width, s.height, frame++);
                    if (data == null) return;

                    Camera.PreviewCallback one = s.oneShotCallback;
                    s.oneShotCallback = null;
                    if (one != null) {
                        one.onPreviewFrame(data, c);
                        return;
                    }

                    Camera.PreviewCallback cb = s.previewCallback;
                    if (cb != null) {
                        byte[] target = s.buffer;
                        if (target != null && target.length >= data.length) {
                            System.arraycopy(data, 0, target, 0, data.length);
                            cb.onPreviewFrame(target, c);
                            s.buffer = null;
                        } else {
                            cb.onPreviewFrame(data, c);
                        }
                    }
                } catch (Throwable t) {
                    XposedBridge.log("VirtualCam frame: " + t);
                }
            }
        }, 0, Math.max(1, 1000 / fps), TimeUnit.MILLISECONDS);
    }

    private static class CamState {
        int cameraId = 0;
        int facing = Camera.CameraInfo.CAMERA_FACING_BACK;
        int width = 640;
        int height = 480;
        Camera.PreviewCallback previewCallback;
        Camera.PreviewCallback oneShotCallback;
        byte[] buffer;
        volatile boolean running;
        ScheduledExecutorService executor;

        void stop() {
            running = false;
            if (executor != null) {
                executor.shutdownNow();
                executor = null;
            }
        }
    }

    private static class Config {
        boolean enabled = true;
        boolean frontEnabled = true;
        boolean backEnabled = true;
        int fps = 15;

        static Config read() {
            Config c = new Config();
            try {
                Properties p = new Properties();
                File f = new File(ROOT, "config.properties");
                if (!f.exists()) return c;
                FileInputStream in = new FileInputStream(f);
                p.load(in);
                in.close();
                c.enabled = Boolean.parseBoolean(p.getProperty("enabled", "true"));
                c.frontEnabled = Boolean.parseBoolean(p.getProperty("frontEnabled", "true"));
                c.backEnabled = Boolean.parseBoolean(p.getProperty("backEnabled", "true"));
                try { c.fps = Integer.parseInt(p.getProperty("fps", "15")); }
                catch (Throwable ignored) {}
            } catch (Throwable ignored) {}
            return c;
        }
    }

    private static class MediaSource {
        private static final MediaMetadataRetriever RETRIEVER = new MediaMetadataRetriever();
        private static String currentPath = "";
        private static int currentW = -1, currentH = -1;

        static synchronized byte[] frameNv21(int facing, int width, int height, long frameIndex) {
            if (!isEnabledFileForFacing(facing)) return null;
            File f = selectedFile(facing);
            if (f == null || !f.exists()) return null;

            if (f.getName().toLowerCase().endsWith(".jpg")
                    || f.getName().toLowerCase().endsWith(".jpeg")
                    || f.getName().toLowerCase().endsWith(".png")) {
                Bitmap b = BitmapFactory.decodeFile(f.getAbsolutePath());
                if (b == null) return null;
                Bitmap scaled = Bitmap.createScaledBitmap(b, width, height, true);
                return bitmapToNv21(scaled, width, height);
            }

            try {
                if (!f.getAbsolutePath().equals(currentPath)) {
                    try { RETRIEVER.release(); } catch (Throwable ignored) {}
                    // Create a new retriever instance after release.
                    // Reflection-free creation is easiest by a local variable.
                    MediaMetadataRetriever r = new MediaMetadataRetriever();
                    r.setDataSource(f.getAbsolutePath());
                    currentPath = f.getAbsolutePath();
                    currentW = width; currentH = height;
                    Bitmap bm = getFrame(r, frameIndex);
                    byte[] out = bitmapToNv21(Bitmap.createScaledBitmap(bm, width, height, true), width, height);
                    return out;
                }
                Bitmap bm = getFrame(RETRIEVER, frameIndex);
                if (bm == null) return null;
                Bitmap scaled = Bitmap.createScaledBitmap(bm, width, height, true);
                return bitmapToNv21(scaled, width, height);
            } catch (Throwable t) {
                // Fallback: open one retriever per frame to avoid stale state.
                try {
                    MediaMetadataRetriever r = new MediaMetadataRetriever();
                    r.setDataSource(f.getAbsolutePath());
                    Bitmap bm = r.getFrameAtTime(0);
                    r.release();
                    if (bm == null) return null;
                    return bitmapToNv21(Bitmap.createScaledBitmap(bm, width, height, true), width, height);
                } catch (Throwable ignored) {
                    return null;
                }
            }
        }

        private static Bitmap getFrame(MediaMetadataRetriever r, long idx) {
            long duration = 1;
            try {
                String d = r.extractMetadata(
                        MediaMetadataRetriever.METADATA_KEY_DURATION);
                duration = Math.max(1, Long.parseLong(d));
            } catch (Throwable ignored) {}
            long ms = (idx * 1000L / Math.max(1, Config.read().fps)) % duration;
            return r.getFrameAtTime(ms * 1000L,
                    MediaMetadataRetriever.OPTION_CLOSEST);
        }

        static byte[] loadJpeg(int facing, int width, int height) {
            try {
                File f = selectedFile(facing);
                if (f == null || !f.exists()) return null;

                if (f.getName().toLowerCase().endsWith(".mp4")) {
                    MediaMetadataRetriever r = new MediaMetadataRetriever();
                    r.setDataSource(f.getAbsolutePath());
                    Bitmap b = r.getFrameAtTime(0);
                    r.release();
                    if (b == null) return null;
                    return jpeg(Bitmap.createScaledBitmap(b, width, height, true));
                }

                byte[] bytes = readAll(f);
                // Validate decode to avoid returning arbitrary unsupported data.
                Bitmap b = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                return b == null ? null : bytes;
            } catch (Throwable t) {
                return null;
            }
        }

        private static boolean isEnabledFileForFacing(int facing) {
            Config c = Config.read();
            return facing == Camera.CameraInfo.CAMERA_FACING_FRONT
                    ? c.frontEnabled : c.backEnabled;
        }

        private static File selectedFile(int facing) {
            File mp4 = new File(ROOT, facing == Camera.CameraInfo.CAMERA_FACING_FRONT
                    ? "front.mp4" : "back.mp4");
            if (mp4.exists()) return mp4;
            File jpg = new File(ROOT, facing == Camera.CameraInfo.CAMERA_FACING_FRONT
                    ? "front.jpg" : "back.jpg");
            if (jpg.exists()) return jpg;
            return null;
        }

        private static byte[] jpeg(Bitmap b) throws Exception {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            b.compress(Bitmap.CompressFormat.JPEG, 92, out);
            return out.toByteArray();
        }

        private static byte[] readAll(File f) throws Exception {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            FileInputStream in = new FileInputStream(f);
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            in.close();
            return out.toByteArray();
        }

        private static byte[] bitmapToNv21(Bitmap bmp, int width, int height) {
            int[] argb = new int[width * height];
            bmp.getPixels(argb, 0, width, 0, 0, width, height);

            byte[] yuv = new byte[width * height * 3 / 2];
            int yIndex = 0;
            int uvIndex = width * height;
            for (int j = 0; j < height; j++) {
                for (int i = 0; i < width; i++) {
                    int c = argb[j * width + i];
                    int r = (c >> 16) & 0xff;
                    int g = (c >> 8) & 0xff;
                    int b = c & 0xff;

                    int y = ((66 * r + 129 * g + 25 * b + 128) >> 8) + 16;
                    int u = ((-38 * r - 74 * g + 112 * b + 128) >> 8) + 128;
                    int v = ((112 * r - 94 * g - 18 * b + 128) >> 8) + 128;

                    yuv[yIndex++] = (byte) clamp(y);
                    if ((j & 1) == 0 && (i & 1) == 0 && uvIndex + 1 < yuv.length) {
                        yuv[uvIndex++] = (byte) clamp(v);
                        yuv[uvIndex++] = (byte) clamp(u);
                    }
                }
            }
            return yuv;
        }

        private static int clamp(int x) {
            return x < 0 ? 0 : (x > 255 ? 255 : x);
        }
    }
}
