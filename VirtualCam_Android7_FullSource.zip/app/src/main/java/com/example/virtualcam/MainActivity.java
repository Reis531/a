package com.example.virtualcam;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;

public class MainActivity extends Activity {
    private static final int REQ_FRONT = 10;
    private static final int REQ_BACK = 11;
    private static final int REQ_PERMS = 12;

    private File rootDir;
    private TextView frontLabel;
    private TextView backLabel;
    private CheckBox enabledBox;
    private CheckBox frontBox;
    private CheckBox backBox;
    private Spinner fpsSpinner;

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        rootDir = new File(Environment.getExternalStorageDirectory(), "VirtualCam");
        if (!rootDir.exists()) rootDir.mkdirs();

        requestStoragePermissions();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24,24,24,24);
        root.setGravity(Gravity.TOP);

        TextView title = new TextView(this);
        title.setText("VirtualCam Android 7");
        title.setTextSize(24);
        root.addView(title);

        TextView info = new TextView(this);
        info.setText("Xposed + Camera1. Seçtiğin medya, hedef uygulamaların kamera önizleme callback/JPEG çıkışında kullanılır.");
        info.setPadding(0,12,0,18);
        root.addView(info);

        enabledBox = new CheckBox(this);
        enabledBox.setText("Virtual camera aktif");
        root.addView(enabledBox);

        frontBox = new CheckBox(this);
        frontBox.setText("Ön kamerada uygula");
        root.addView(frontBox);

        backBox = new CheckBox(this);
        backBox.setText("Arka kamerada uygula");
        root.addView(backBox);

        root.addView(new TextView(this) {{ setText("Ön kamera medyası:"); }});
        frontLabel = new TextView(this);
        root.addView(frontLabel);

        Button frontButton = new Button(this);
        frontButton.setText("Ön kamera için Video/Fotoğraf seç");
        frontButton.setOnClickListener(v -> pick(REQ_FRONT));
        root.addView(frontButton);

        root.addView(new TextView(this) {{ setText("Arka kamera medyası:"); }});
        backLabel = new TextView(this);
        root.addView(backLabel);

        Button backButton = new Button(this);
        backButton.setText("Arka kamera için Video/Fotoğraf seç");
        backButton.setOnClickListener(v -> pick(REQ_BACK));
        root.addView(backButton);

        LinearLayout fpsRow = new LinearLayout(this);
        fpsRow.setOrientation(LinearLayout.HORIZONTAL);
        TextView fpsText = new TextView(this);
        fpsText.setText("Önizleme FPS: ");
        fpsRow.addView(fpsText);
        fpsSpinner = new Spinner(this);
        String[] fpsValues = {"10","15","20","24","30"};
        fpsSpinner.setAdapter(new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_dropdown_item, fpsValues));
        fpsRow.addView(fpsSpinner);
        root.addView(fpsRow);

        Button save = new Button(this);
        save.setText("AYARLARI KAYDET");
        save.setOnClickListener(v -> saveConfig());
        root.addView(save);

        Button clear = new Button(this);
        clear.setText("Medya seçimlerini temizle");
        clear.setOnClickListener(v -> clearMedia());
        root.addView(clear);

        TextView path = new TextView(this);
        path.setText("Dosyalar: " + rootDir.getAbsolutePath());
        path.setPadding(0,20,0,0);
        root.addView(path);

        setContentView(root);
        loadConfig();
    }

    private void requestStoragePermissions() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{
                        Manifest.permission.READ_EXTERNAL_STORAGE,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE
                }, REQ_PERMS);
            }
        }
    }

    private void pick(int requestCode) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, requestCode);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            String mime = getContentResolver().getType(uri);
            boolean video = mime != null && mime.startsWith("video/");
            boolean image = mime != null && mime.startsWith("image/");
            if (!video && !image) {
                toast("Sadece video veya fotoğraf seç.");
                return;
            }
            File dst = new File(rootDir, requestCode == REQ_FRONT
                    ? (video ? "front.mp4" : "front.jpg")
                    : (video ? "back.mp4" : "back.jpg"));

            // Remove stale media of the opposite type.
            delete(new File(rootDir, requestCode == REQ_FRONT ? "front.mp4" : "front.jpg"));
            delete(new File(rootDir, requestCode == REQ_FRONT ? "back.mp4" : "back.jpg"));

            try (InputStream in = getContentResolver().openInputStream(uri);
                 OutputStream out = new FileOutputStream(dst)) {
                byte[] buf = new byte[1024 * 1024];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            }

            if (requestCode == REQ_FRONT) frontLabel.setText(dst.getName() + " (" + dst.length() + " bytes)");
            else backLabel.setText(dst.getName() + " (" + dst.length() + " bytes)");
            saveConfig();
            toast("Medya kopyalandı.");
        } catch (Exception e) {
            toast("Kopyalama hatası: " + e.getMessage());
        }
    }

    private void saveConfig() {
        try {
            Properties p = new Properties();
            p.setProperty("enabled", Boolean.toString(enabledBox.isChecked()));
            p.setProperty("frontEnabled", Boolean.toString(frontBox.isChecked()));
            p.setProperty("backEnabled", Boolean.toString(backBox.isChecked()));
            p.setProperty("fps", String.valueOf(fpsSpinner.getSelectedItem()));
            File f = new File(rootDir, "config.properties");
            try (FileOutputStream out = new FileOutputStream(f)) {
                p.store(out, "VirtualCam settings");
            }
            toast("Ayarlar kaydedildi. Hedef uygulamayı tamamen kapatıp yeniden aç.");
        } catch (Exception e) {
            toast("Ayar hatası: " + e.getMessage());
        }
    }

    private void loadConfig() {
        try {
            Properties p = new Properties();
            File f = new File(rootDir, "config.properties");
            if (f.exists()) {
                try (FileInputStream in = new FileInputStream(f)) {
                    p.load(in);
                }
            }
            enabledBox.setChecked(Boolean.parseBoolean(p.getProperty("enabled", "true")));
            frontBox.setChecked(Boolean.parseBoolean(p.getProperty("frontEnabled", "true")));
            backBox.setChecked(Boolean.parseBoolean(p.getProperty("backEnabled", "true")));
            String fps = p.getProperty("fps", "15");
            ArrayAdapter<?> a = (ArrayAdapter<?>) fpsSpinner.getAdapter();
            for (int n = 0; n < a.getCount(); n++) {
                if (fps.equals(a.getItem(n).toString())) {
                    fpsSpinner.setSelection(n);
                    break;
                }
            }
            frontLabel.setText(existing("front.mp4", "front.jpg"));
            backLabel.setText(existing("back.mp4", "back.jpg"));
        } catch (Exception e) {
            toast("Ayar okunamadı.");
        }
    }

    private String existing(String a, String b) {
        File fa = new File(rootDir, a);
        if (fa.exists()) return fa.getName() + " (" + fa.length() + " bytes)";
        File fb = new File(rootDir, b);
        if (fb.exists()) return fb.getName() + " (" + fb.length() + " bytes)";
        return "Seçilmedi";
    }

    private void clearMedia() {
        delete(new File(rootDir, "front.mp4"));
        delete(new File(rootDir, "front.jpg"));
        delete(new File(rootDir, "back.mp4"));
        delete(new File(rootDir, "back.jpg"));
        frontLabel.setText("Seçilmedi");
        backLabel.setText("Seçilmedi");
        toast("Medya temizlendi.");
    }

    private void delete(File f) { if (f.exists()) f.delete(); }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }
}
