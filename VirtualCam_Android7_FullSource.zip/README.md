# VirtualCam Android 7 — Xposed Camera1

Bu proje sıfırdan hazırlanmış bir Android 7 uyumlu Xposed modül + kontrol uygulamasıdır.

HEDEF:
- Magisk gerekmez.
- Android 7 (API 24/25) hedeflenmiştir.
- Root + klasik Xposed Framework gerekir.
- Camera1 kullanan uygulamalarda preview callback'lerine seçilen fotoğraf/video frame'lerini vermek.
- Fotoğraf çekimindeki JPEG callback'ini seçilen fotoğraf veya videodan alınan ilk frame ile değiştirmek.
- Ön ve arka kamera için ayrı medya dosyaları seçebilmek.
- Video loop + ayarlanabilir FPS.

KISITLAMA:
Android'in Camera1 API'sinde gerçek preview görüntüsü Surface/SurfaceTexture üzerinden
gösteriliyorsa, yalnızca callback hook'u o Surface'i değiştirmez. Bu nedenle bu sürüm
"tüm kamera uygulamalarında %100 çalışan sistem sanal kamera" değildir. Camera1 preview
callback kullanan uygulamalarda hedeflenen işlevi sağlar; doğrudan Surface preview kullanan
uygulamalar için ayrıca native/GL seviyesinde bir çözüm gerekir.

KURULUM:
1) Android 7 VM'ye cihazın mimarisine uygun klasik Xposed Framework kur.
2) Bu APK'yı yükle.
3) Xposed Installer -> Modules -> VirtualCam Android 7'yi etkinleştir.
4) Yeniden başlat.
5) VirtualCam uygulamasını aç.
6) Ön/arka medya seç, Virtual camera aktif yap, ayarları kaydet.
7) Hedef uygulamayı tamamen kapatıp yeniden aç.
8) Dosyalar /sdcard/VirtualCam altında tutulur.

DERLEME:
- Android Studio ile proje klasörünü aç.
- `app/libs/xposed-api-stub.jar` sadece derleme içindir; APK içine paketlenmez.
- Gradle/Android SDK kurulumu gerekir.
- targetSdk 25, minSdk 21.

DOSYA YAPISI:
app/src/main/assets/xposed_init
app/src/main/java/com/example/virtualcam/MainActivity.java
app/src/main/java/com/example/virtualcam/xposed/VirtualCamHook.java
app/libs/xposed-api-stub.jar

DİKKAT:
Kamera uygulamasının CAMERA ve/veya depolama izinleri verilmiş olmalıdır.
